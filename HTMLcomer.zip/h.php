<?php
// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  // Récupérer les données du formulaire
  $to = "votre_email@example.com"; // adresse e-mail du destinataire
  $subject = "Nouvelle commande"; // sujet du message
  $message = "Produit : " . $_POST['product'] . "\r\n";
  $message .= "Prix : " . $_POST['price'] . "\r\n";
  $message .= "Nom : " . $_POST['name'] . "\r\n";
  $message .= "Adresse e-mail : " . $_POST['email'] . "\r\n";
  $message .= "Adresse : " . $_POST['address'] . "\r\n";
  $message .= "Ville : " . $_POST['city'] . "\r\n";
  $message .= "Code postal : " . $_POST['zip'] . "\r\n";
  
  // En-têtes du message
  $headers = "From: MonSiteEcommerce.com <noreply@monsiteecommerce.com>\r\n";
  $headers .= "Reply-To: " . $_POST['email'] . "\r\n";
  $headers .= "CC: " . $_POST['email'] . "\r\n";
  $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
  
  // Envoyer l'e-mail
  if (mail($to, $subject, $message, $headers)) {
    echo "<p>Votre commande a été envoyée avec succès.</p>";
  } else {
    echo "<p>Une erreur s'est produite lors de l'envoi de votre commande. Veuillez réessayer plus tard.</p>";
  }
}
?>
