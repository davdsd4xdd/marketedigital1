const form = document.querySelector('form');
const submitBtn = document.querySelector('#submitBtn');

form.addEventListener('submit', (event) => {
  event.preventDefault();
  // validate card number, exp date, cvv, and name
  // if valid, submit form to payment processor
  // otherwise, show error message
});
